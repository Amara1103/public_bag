# import all contents from C++ extension module
from ._skgeom import *

from ._version import version_info, __version__